﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Chushka.Data
{
    public class ChushkaContext : DbContext
    {
        public ChushkaContext()
        {

        }
        public ChushkaContext(DbContextOptions<ChushkaContext> options) :
    base(options)
        { 
        
        }
        public virtual DbSet<User> Users { get; set; }
        public virtual DbSet<Product> Products { get; set; }
        public virtual DbSet<Order> Orders { get; set; }
    }
}
